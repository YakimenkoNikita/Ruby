require_relative "polish_line"

test_strings = [
    "((2 + 1))",
    "sin(sin(2 + 10)) + 11",
    "(((1 + (5 * 2)) / 11 + 2))",
    "(1 + 4) * 2",
    "(2^3 - 8) / 0"
]

i = 0
while i < 4 do 
    puts "Simple line: #{test_strings[i]}" 
    polishLine = polish_line_parser(test_strings[i])
    puts "Polish line: #{polishLine}" 
    puts "Resutl: #{polish_calculator(polishLine)}"
    puts "--------------------"
    i += 1
end