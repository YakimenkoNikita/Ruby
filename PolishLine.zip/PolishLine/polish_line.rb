require_relative "read_text"
require_relative "operators_libs"


def calculator(operator, value)
    res = 0.0

    if operator == "cos"
        res = Math::cos(value[0])
    elsif operator == "sin"
        res = Math::sin(value[0])
    elsif operator == "tan"
        res = Math::tan(value[0])
    elsif operator == "cot"
        res = Math::cot(value[0])
    elsif operator == "+"
        res = value[0] + value[1]
    elsif operator == "-"
        res = value[0] - value[1]
    elsif operator == "*"
        res = value[0] * value[1]
    elsif operator == "/"
        begin
            res = value[0] / value[1]
        rescue ZeroDivisionError => error
            puts error.message
            exit(1)
        end
    elsif operator == "^"
        res = value[0].pow(value[1])
    end

    res
end

def polish_calculator(res_line)
    sres = Array.new

    i = 0
    while i < res_line.length do 
        substr =  get_next(i, res_line)

        i += substr.length()
        if substr =~ /[[:blank:]]/ 
            next
        end

        if substr =~ /[[:digit:]]/
            sres.push(substr)
        else
            res = 0.0
            val = Array.new

            if ONE_VALUE_OPERATORS.include?(substr)
                val[0] = sres.pop.to_f
                res = calculator(substr, val)
            elsif TWO_VALUE_OPERATORS.include?(substr)
                val[1] = sres.pop.to_f
                val[0] = sres.pop.to_f
                res = calculator(substr, val)
            else
                puts "Error in polish_calculator(), non undefined operation"
                exit(1)
            end
            sres.push(res)
        end
    end

    sres.pop
end

def polish_line_parser(string)
    res_line = ""
    stack = Array.new

    i = 0
    while i < string.length do 
        substr = get_next(i, string)

        i += substr.length()
        if substr =~ /[[:blank:]]/ 
            next
        end

        if substr =~ /[[:digit:]]/
            res_line << substr << " "
        elsif substr == "("
            stack.push(substr)
        elsif substr == ")"
            while stack.last != "(" do
                res_line << stack.pop << " "
            end

            stack.pop
        else
            if stack.empty? || 
                MY_OPERATION_PRIORITY[stack.last] < MY_OPERATION_PRIORITY[substr]
                stack.push(substr)
            else
                while !stack.empty? && 
                    MY_OPERATION_PRIORITY[stack.last] >= MY_OPERATION_PRIORITY[substr] do
                    res_line << stack.pop << " "
                end
                
                stack.push(substr)
            end
        end
    end

    while !stack.empty?
        res_line << stack.pop
    end

    res_line
end