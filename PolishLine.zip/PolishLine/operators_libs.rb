MY_OPERATION_PRIORITY = {
    "(" => 0,
    "+" => 1,
    "-" => 1,
    "*" => 2,
    "/" => 2,
    "^" => 3, 
    "sin" => 4,
    "cos" => 4,
    "tan" => 4,
    "cot" => 4
}

ONE_VALUE_OPERATORS = ["sin", "cos", "tan", "cot"]
TWO_VALUE_OPERATORS = ["+", "-", "/", "*", "^"]