require_relative "Iterators"
require_relative "Notification"
require_relative "Gmail"


class Gmail

    private
    @@message_list

    public 
    def initialize()
        @@message_list = Array.new
    end

    def addMessage(msg)
        @@message_list.push(msg)
    end

    def removeMessage(msg)
        @@message_list.pop(msg)
    end

    def iterator(sender)
        return SenderIterator.new(sender, @@message_list)
    end

    def allMessage()
        i = 0
        while i < @@message_list.size() do
            @@message_list.at(i).toString()
            i += 1
        end
    end
           
end 
