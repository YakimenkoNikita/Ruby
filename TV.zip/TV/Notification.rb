class Notification 
    private 
    attr_accessor :sender, :message
    public
    def initialize(s, m)
        @sender = s
        @message = m
    end

    def getSender()
        self.sender
    end

    def toString()
        puts "#{self.sender} => \"#{self.message}\""
    end
end