class IIterator
    
    def hasNext() end
    def next() end
end

class SenderIterator < IIterator

    private
    @@sender
    @@message_list
    @@position

    public
    def initialize(s, ml)
        @@message_list = ml
        @@sender = s
        @@position = 0
    end

    def hasNext() 
        while @@position < @@message_list.size() do
            if @@sender == @@message_list.at(@@position).getSender()
                return true
            else
                @@position += 1
            end
        end
        false
    end

    def next() 
        mes = @@message_list.at(@@position)
        @@position += 1
        mes
    end
        
end