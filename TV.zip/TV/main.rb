require_relative "Iterators"
require_relative "Notification"
require_relative "Gmail"

def main
    m = xxx()

    puts "All message: "
    m.allMessage()

    puts "\nKarazina message: "
    karazina_iterator = m.iterator("karazina@gmal.com")

    while karazina_iterator.hasNext() do
        karazina_iterator.next().toString()
    end

end

def xxx() 
    gmail = Gmail.new()
    gmail.addMessage(Notification.new("steam@gmal.com", "play in Dota"))
    gmail.addMessage(Notification.new("steam@gmal.com", "play in CS"))
    gmail.addMessage(Notification.new("steam@gmal.com", "play in BF5"))
    gmail.addMessage(Notification.new("karazina@gmal.com", "you have a new task "))
    gmail.addMessage(Notification.new("karazina@gmal.com", "you have a new task "))
    gmail.addMessage(Notification.new("karazina@gmal.com", "you have a new task "))
    gmail
end

main()